using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;

public class Hosting
{
    private readonly TelegramBotClient botClient;
    
    public Hosting(string token)
    {
        botClient = new TelegramBotClient(token);
    }  

    public void Start()
    {
        // Начало работы бота
        botClient.StartReceiving(UpdateHandler, ErrorHandler);
        Console.WriteLine("bot started");
    }

    private async Task ErrorHandler(ITelegramBotClient client, Exception exception, HandleErrorSource source, CancellationToken token)
    {
        Console.WriteLine($"Ошибка: {exception.Message}");
        await Task.CompletedTask;
    }

    private async Task UpdateHandler(ITelegramBotClient client, Update update, CancellationToken token)
    {
        Console.WriteLine($"Принято: {update.Message?.Text ?? "Стикер"}");
        await Task.CompletedTask;
    }
}