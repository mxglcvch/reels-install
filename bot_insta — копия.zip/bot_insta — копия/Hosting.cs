using System;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

public class Hosting
{
    private readonly TelegramBotClient _bot;

    public Hosting(string token) => _bot = new TelegramBotClient(token);

    public void Start()
    {
        _bot.StartReceiving(
            updateHandler: HandleUpdateAsync,
            errorHandler: HandleErrorAsync,
            receiverOptions: new ReceiverOptions
            {
                DropPendingUpdates = true,  // Важно для v19+!
                AllowedUpdates = Array.Empty<UpdateType>()  // Получать все типы сообщений
            }
        );
        
        Console.WriteLine("Бот запущен!");
    }

    private async Task HandleUpdateAsync(ITelegramBotClient bot, Update update, CancellationToken ct)
    {
        Console.WriteLine($"Получено: {update.Message?.Text ?? "Стикер/файл"}");
        await Task.CompletedTask;
    }

    private async Task HandleErrorAsync(ITelegramBotClient bot, Exception ex, CancellationToken ct)
    {
        Console.WriteLine($"Ошибка: {ex.Message}");
        await Task.CompletedTask;
    }
}