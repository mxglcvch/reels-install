﻿using System;
using System.Collections.Generic;

internal class Program
{
     private static void Main()
    {
        Hosting reelsbot = new Hosting(7990981148:AAHkwwIlD6bwHq8EGuAT2 - 2nB2fk1u0pYK0);
        reelsbot.Start();
        Console.ReadLine();
    }

    

}